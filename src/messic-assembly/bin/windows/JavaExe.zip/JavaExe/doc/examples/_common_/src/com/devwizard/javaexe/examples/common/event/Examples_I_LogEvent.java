/*****************************************************************************/
/***  (c) 2002-2013, DevWizard (DevWizard@free.fr)                         ***/
/*****************************************************************************/

package com.devwizard.javaexe.examples.common.event;


/*****************************************************************************/
public interface Examples_I_LogEvent
{
	public void logEvent(String event, String param);
}
