/*****************************************************************************/
/***  (c) 2002-2013, DevWizard (DevWizard@free.fr)                         ***/
/***                                                                       ***/
/***                                                                       ***/
/***   Example 17                                                          ***/
/***                                                                       ***/
/*****************************************************************************/

package com.devwizard.javaexe.examples.example17;


import com.devwizard.javaexe.examples.common.*;


/*****************************************************************************/
public class Example17_Config extends Examples_Config
{
	/*******************************************/
	public static void init()
	{
		init("Example17");
	}
}
