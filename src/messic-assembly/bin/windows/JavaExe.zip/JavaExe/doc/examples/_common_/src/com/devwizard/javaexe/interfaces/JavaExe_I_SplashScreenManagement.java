/*****************************************************************************/
/***  (c) 2002-2013, DevWizard (DevWizard@free.fr)                         ***/
/*****************************************************************************/

package com.devwizard.javaexe.interfaces;


/*****************************************************************************/
public interface JavaExe_I_SplashScreenManagement
{
	/*******************************************/
	// public static void sphInit();
	// public static void sphFinish();

	// public static boolean sphIsClose();
	// public static int sphGetTickCount();

	// public static String[] sphGetProgressBarInfo();
	// public static int sphGetProgressBarValue();

	// public static void sphPaint(Graphics2D g, int wWnd, int hWnd);
}
