/*****************************************************************************/
/***  (c) 2002-2013, DevWizard (DevWizard@free.fr)                         ***/
/***                                                                       ***/
/***                                                                       ***/
/***   Example 7                                                           ***/
/***                                                                       ***/
/*****************************************************************************/

package com.devwizard.javaexe.examples.example7;


import com.devwizard.javaexe.examples.common.*;


/*****************************************************************************/
public class Example7_Config extends Examples_Config
{
	/*******************************************/
	public static void init()
	{
		init("Example7");
	}
}
