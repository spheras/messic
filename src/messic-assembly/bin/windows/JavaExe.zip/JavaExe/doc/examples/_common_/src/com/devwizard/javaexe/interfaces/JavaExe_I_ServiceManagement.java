/*****************************************************************************/
/***  (c) 2002-2013, DevWizard (DevWizard@free.fr)                         ***/
/*****************************************************************************/

package com.devwizard.javaexe.interfaces;


/*****************************************************************************/
public interface JavaExe_I_ServiceManagement
{
	/*******************************************/
	// public static boolean serviceIsCreate();
	// public static boolean serviceIsLaunch();
	// public static boolean serviceIsDelete();

	// public static boolean serviceControl_Pause();
	// public static boolean serviceControl_Continue();
	// public static boolean serviceControl_Stop();
	// public static boolean serviceControl_Shutdown();

	// public static boolean serviceInit();
	// public static void serviceFinish();

	// public static void serviceDataFromUI(Serializable data);
	// public static boolean serviceIsDataForUI();
	// public static Serializable serviceDataForUI();

	// public static String[] serviceGetInfo();
}
