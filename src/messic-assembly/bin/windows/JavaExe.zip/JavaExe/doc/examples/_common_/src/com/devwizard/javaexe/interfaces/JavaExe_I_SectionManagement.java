/*****************************************************************************/
/***  (c) 2002-2013, DevWizard (DevWizard@free.fr)                         ***/
/*****************************************************************************/

package com.devwizard.javaexe.interfaces;


/*****************************************************************************/
public interface JavaExe_I_SectionManagement
{
	/*******************************************/
	// public static native boolean sectionIsAdmin();
	// public static native boolean sectionExecAsAdmin(String pathname, String[] mainArgs);
	// public static native void sectionRestartAsAdmin(Serializable data, String[] mainArgs);
	// public static native void sectionSetIconAdmin(Component comp);
	// public static native boolean sectionStartAdminThread(int numID, Serializable data, boolean isWait);

	// public static void sectionSetDataRestart(Serializable data);

	// public static void sectionMainAdmin(int numID, Serializable data);
	// public static void sectionClosedAdminThread(int numID);

	// public static boolean sectionIsDataForAdmin(int numID);
	// public static Serializable sectionDataForAdmin(int numID);
	// public static void sectionDataFromAdmin(int numID, Serializable data);

	// public static boolean sectionIsDataForUser();
	// public static Serializable sectionDataForUser();
	// public static void sectionDataFromUser(Serializable data);
}
