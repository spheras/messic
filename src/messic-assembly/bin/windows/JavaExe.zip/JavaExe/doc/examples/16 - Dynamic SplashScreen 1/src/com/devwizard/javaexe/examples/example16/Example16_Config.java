/*****************************************************************************/
/***  (c) 2002-2013, DevWizard (DevWizard@free.fr)                         ***/
/***                                                                       ***/
/***                                                                       ***/
/***   Example 16                                                          ***/
/***                                                                       ***/
/*****************************************************************************/

package com.devwizard.javaexe.examples.example16;


import com.devwizard.javaexe.examples.common.*;


/*****************************************************************************/
public class Example16_Config extends Examples_Config
{
	/*******************************************/
	public static void init()
	{
		init("Example16");
	}
}
