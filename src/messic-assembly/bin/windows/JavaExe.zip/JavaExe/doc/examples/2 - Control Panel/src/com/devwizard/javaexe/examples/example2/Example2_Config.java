/*****************************************************************************/
/***  (c) 2002-2013, DevWizard (DevWizard@free.fr)                         ***/
/***                                                                       ***/
/***                                                                       ***/
/***   Example 2                                                           ***/
/***                                                                       ***/
/*****************************************************************************/

package com.devwizard.javaexe.examples.example2;


import com.devwizard.javaexe.examples.common.*;


/*****************************************************************************/
public class Example2_Config extends Examples_Config
{
	/*******************************************/
	public static void init()
	{
		init("Example2");
	}
}
