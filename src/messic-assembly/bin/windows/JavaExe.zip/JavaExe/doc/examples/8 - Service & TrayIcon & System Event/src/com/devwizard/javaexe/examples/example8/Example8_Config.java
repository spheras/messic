/*****************************************************************************/
/***  (c) 2002-2013, DevWizard (DevWizard@free.fr)                         ***/
/***                                                                       ***/
/***                                                                       ***/
/***   Example 8                                                           ***/
/***                                                                       ***/
/*****************************************************************************/

package com.devwizard.javaexe.examples.example8;


import com.devwizard.javaexe.examples.common.*;


/*****************************************************************************/
public class Example8_Config extends Examples_Config
{
	/*******************************************/
	public static void init()
	{
		init("Example8");
	}
}
