/*****************************************************************************/
/***  (c) 2002-2013, DevWizard (DevWizard@free.fr)                         ***/
/***                                                                       ***/
/***                                                                       ***/
/***   Example 11                                                          ***/
/***                                                                       ***/
/*****************************************************************************/

package com.devwizard.javaexe.examples.example11;


import com.devwizard.javaexe.examples.common.*;


/*****************************************************************************/
public class Example11_Config extends Examples_Config
{
	/*******************************************/
	public static void init()
	{
		init("Example11");
	}
}
