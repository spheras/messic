/*****************************************************************************/
/***  (c) 2002-2013, DevWizard (DevWizard@free.fr)                         ***/
/*****************************************************************************/

package com.devwizard.javaexe.interfaces;


/*****************************************************************************/
public interface JavaExe_I_ApplicationManagement
{
	/*******************************************/
	// public static boolean isOneInstance(String[] args);


	/*******************************************/
	// public static boolean sessionIsRestore();
	// public static String[] sessionGetMainArgs();
	// public static Serializable sessionGetData();
	// public static void sessionSetData(Serializable data);
}
