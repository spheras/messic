/*****************************************************************************/
/***  (c) 2002-2013, DevWizard (DevWizard@free.fr)                         ***/
/***                                                                       ***/
/***                                                                       ***/
/***   Example 22                                                          ***/
/***                                                                       ***/
/*****************************************************************************/

package com.devwizard.javaexe.examples.example22;


/*****************************************************************************/
public interface Example22_I_Callback
{
	public void showPanelInfo(String nameSvc, boolean isShow);
	public void updateList();
}
