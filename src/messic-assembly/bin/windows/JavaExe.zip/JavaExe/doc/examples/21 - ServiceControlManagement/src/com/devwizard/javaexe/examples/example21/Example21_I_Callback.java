/*****************************************************************************/
/***  (c) 2002-2013, DevWizard (DevWizard@free.fr)                         ***/
/***                                                                       ***/
/***                                                                       ***/
/***   Example 21                                                          ***/
/***                                                                       ***/
/*****************************************************************************/

package com.devwizard.javaexe.examples.example21;


/*****************************************************************************/
public interface Example21_I_Callback
{
	public void showPanelInfo(String nameSvc, boolean isShow);
	public void updateList();
}
