/*****************************************************************************/
/***  (c) 2002-2013, DevWizard (DevWizard@free.fr)                         ***/
/*****************************************************************************/

package com.devwizard.javaexe.interfaces;


/*****************************************************************************/
public interface JavaExe_I_ScreenSaverManagement
{
	/*******************************************/
	// public static boolean scrsvIsCreate();
	// public static boolean scrsvIsDelete();

	// public static void scrsvInit();
	// public static void scrsvFinish();

	// public static void scrsvOpenConfig();
	// public static void scrsvPaint(Graphics2D g, int wScr, int hScr);

	// public static boolean scrsvIsExitByKey(int keycode, boolean isUp);
	// public static boolean scrsvIsExitByMouse(int x, int y, int nbClick, int button, boolean isUp);

	// public static String[] scrsvGetInfo();
}
