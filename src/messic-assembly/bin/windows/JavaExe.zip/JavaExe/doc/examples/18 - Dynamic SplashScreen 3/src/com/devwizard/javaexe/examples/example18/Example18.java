/*****************************************************************************/
/***  (c) 2002-2013, DevWizard (DevWizard@free.fr)                         ***/
/***                                                                       ***/
/***                                                                       ***/
/***   Example 18                                                          ***/
/***                                                                       ***/
/*****************************************************************************/

package com.devwizard.javaexe.examples.example18;


/*****************************************************************************/
public class Example18
{
	/*******************************************/
	public static void main(String[] args)
	{
		Example18_Config.init();
		Example18_Config.showDialogOption();
	}
}
